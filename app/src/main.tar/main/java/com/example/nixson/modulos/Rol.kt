package com.example.nixson.modulos

enum class Rol {
    ADMIN,
    EMPLEADO
}