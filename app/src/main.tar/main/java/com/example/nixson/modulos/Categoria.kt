package com.example.nixson.modulos

data class Categoria(
    val id: Int,
    val nombre: String
)