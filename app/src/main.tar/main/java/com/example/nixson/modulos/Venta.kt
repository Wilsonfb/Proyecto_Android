package com.example.nixson.modulos

data class Venta(
    val id: Int,
    val producto: String,
    val cantidad: Int
)